public class PriorityQueue<E> /* TODO 1d) */ {
	
	protected class Entry {
		E value;
		int prio;
	}

	protected ArrayList<Entry> elements;

	public PriorityQueue() {
		elements = new ArrayList<Entry>();
	}

	// TODO 1d)
	
	private void bubbleUp(int idx) {
		// TODO 1b)
	}
	
	private void trickleDown(int idx) {
		// TODO 1c)
	}

	// protected und ueberschreiben im Test?? Rene fragen
	protected static int parent(int idx) {
		// TODO 1a)
		return 42;
	}
	
	protected static int leftChild(int idx) {
		// TODO 1a)
		return 42;
	}
	
	protected static int rightChild(int idx) {
		// TODO 1a)
		return 42;
	}
	
}
