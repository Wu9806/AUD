import java.util.Map;

public class Huffman {

	public int[] characterHistogram(String s) {
		// Only ASCII
		int[] histogram = new int[256];

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c < 256) {
				histogram[c]++;
			}
		}

		return histogram;
	}

	public void printHuffmanCoding(Map<Character, String> map) {
		for (Character c : map.keySet()) {
			System.out.println("'" + c + "': " + map.get(c));
		}
	}

	/**
	 * Compute the Huffman coding map for s
	 * 
	 * @param s
	 *            String to encode
	 * @return Huffman coding map
	 */
	public Map<Character, String> huffmanCode(String s) {
		// TODO 3.
		return null;
	}

	/**
	 * @param s
	 *            String to encode
	 * @param map
	 *            Huffman coding map
	 * @return the length of the Huffman coding of s
	 */
	public long lengthHuffmanCoding(String s, Map<Character, String> map) {
		// TODO 4.
		return 42L;
	}

	/**
	 * @param s
	 *            String to encode
	 * @return the length of the 8-bit coding of s
	 */
	public long length8BitCoding(String s) {
		// TODO 4.
		return 42L;
	}

	/**
	 * Compute the compression ratio we can achieve for s given the Huffman
	 * encoding map as compared to 8-bit coding of the symbols.
	 * 
	 * @param s
	 *            String to encode
	 * @param map
	 *            Huffman coding map
	 * @return compression ratio
	 */
	public float computeCompressionRatio(String s, Map<Character, String> map) {
		// TODO 4.
		return 42.f;
	}

	public static void main(String[] args) {

		Huffman h = new Huffman();
		String s = "Insert String here";
		Map<Character, String> map = h.huffmanCode(s);
		h.printHuffmanCoding(map);
		float cr = h.computeCompressionRatio(s, map);

		System.out.println("Compression ratio: " + (cr * 100) + "%");
	}

}
