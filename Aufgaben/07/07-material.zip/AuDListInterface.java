import java.util.Iterator;
import java.util.NoSuchElementException;

public interface AuDListInterface<T extends Comparable<T>> extends Iterable<T> {

	/**
	 * Returns the size of the list.
	 * 
	 * @return the number of items in the list.
	 */
	public int size();

	/**
	 * Checks whether a value already exists in the list.
	 * 
	 * @param value
	 *            The value to be checked
	 * @return true if the value already exists in the list, false otherwise
	 */
	public boolean exists(T value);

	/**
	 * Inserts a value into the list so that all values are still sorted in
	 * ascending order.
	 * 
	 * @param value
	 *            The value to be added to the list
	 * 
	 * @throws ElementExistsException
	 *             if value is already in the list
	 */
	public void insert(T value);

	/**
	 * Removes the first occurrence of a value from the list. </br>
	 * 
	 * [3, 3, 1, 2, 1, 2, 3] -> remove(1) -> [3, 3, 2, 1, 2, 3] </br>
	 * ["abc", "xyz", "ijk", "def", "xyz", "xyz"] -> remove("xyz") -> ["abc", "ijk",
	 * "def", "xyz", "xyz"]
	 * 
	 * @param value
	 *            the value to be removed
	 * @throws NoSuchElementException
	 *             if the list does not contain the specified value
	 */
	public void remove(T value);

	/**
	 * Returns an iterator over the elements in this list in proper sequence.
	 */
	public Iterator<T> iterator();

	/**
	 * Merges the values of another list into this list. After executing merge, this
	 * list contains the values from both lists and is sorted in ascending order.
	 * The other list is <b>not</b> modified. Note that elements from the other list
	 * should only be inserted if they do not already exist in the list.
	 * 
	 * @param other
	 *            the list whose values are to be inserted into this list
	 */
	void merge(AuDListInterface<T> other);

}
