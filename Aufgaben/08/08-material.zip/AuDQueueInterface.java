
public interface AuDQueueInterface {

	/**
	 * Returns true if this queue contains no elements.
	 * 
	 * @return true if this queue contains no elements.
	 */
	public boolean isEmpty();

	/**
	 * Returns the number of elements in this queue.
	 * 
	 * @return the number of elements in this queue.
	 */
	public int size();

	/**
	 * Removes all of the elements from this queue.
	 */
	public void clear();

	/**
	 * Inserts the specified element into this queue, if possible.
	 * 
	 * @param element
	 *            the element to insert.
	 * @return true if it was possible to add the element to this queue, else false.
	 */
	public boolean enqueue(int element);

	/**
	 * Retrieves, but does <b>not</b> remove, the head of this queue.
	 * 
	 * @return the head of this queue.
	 * @throws java.util.NoSuchElementException
	 *             - if this queue is empty.
	 */
	public int peek();

	/**
	 * Retrieves and removes the head of this queue.
	 * 
	 * @return the head of this queue.
	 * @throws java.util.NoSuchElementException
	 *             - if this queue is empty.
	 */
	public int dequeue();

	/**
	 * Returns a string representation of this queue which consists of the string
	 * representations of its elements in the order they would be retrieved by
	 * dequeue, all between brackets and separated from one another by a single
	 * blank, like this:</br>
	 * <code>[a b c d e f]</code>
	 * 
	 * @return a string representation of this queue.
	 */
	@Override
	public String toString();
}
