
public interface AuDStackInterface {

	/**
	 * Returns true if this stack contains no elements.
	 * 
	 * @return true if this stack contains no elements.
	 */
	public boolean isEmpty();

	/**
	 * Returns the number of elements in this stack.
	 * 
	 * @return the number of elements in this stack.
	 */
	public int size();

	/**
	 * Removes all of the elements from this stack.
	 */
	public void clear();

	/**
	 * Inserts the specified element into this stack, if possible.
	 * 
	 * @param element
	 *            the element to insert.
	 * @return true if it was possible to add the element to this stack, else false.
	 */
	public boolean push(int element);

	/**
	 * Retrieves, but does <b>not</b> remove, the element at the top of this stack.
	 * 
	 * @return the element at the top of this stack.
	 * @throws java.util.NoSuchElementException
	 *             - if this stack is empty.
	 */
	public int peek();

	/**
	 * Retrieves and removes the element at the top of this stack.
	 * 
	 * @return the head of this stack.
	 * @throws java.util.NoSuchElementException
	 *             - if this stack is empty.
	 */
	public int pop();

	/**
	 * Returns a string representation of this stack which consists of the string
	 * representations of its elements in the order they would be retrieved by pop,
	 * all between brackets and separated from one another by a single blank, like
	 * this:</br>
	 * <code>[a b c d e f]</code>
	 *
	 * In this stack, "a" would be popped first and "f" would be popped last.
	 * 
	 * @return a string representation of this stack.
	 */
	@Override
	public String toString();
}
